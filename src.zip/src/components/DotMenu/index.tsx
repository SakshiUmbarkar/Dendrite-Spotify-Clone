import React from 'react'
import './styles.css'

const DotMenu = () => {
  return (
    <div className="dotmenu">
      <div/>
      <div/>
      <div/>
    </div>
  )
}

export default DotMenu
